<?php
/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/**
 * The default configuration settings
 *
 * Put any site specific configuration in a config/local.php file, this way
 * your configuration won't be lost when upgrading shindig. If your site don't
 * support any services just use empty string as the service name. i.e.
 *  'messages_service' => ''
 *
 * in local.php you only have to specificy the fields you want to overwrite
 * with other values, for example on a production system you would probably have:
 * $shindigConfig = array(
 * 	'debug' => false,
 * 	'allow_plaintext_token' => false,
 * 	'token_cipher_key' => 'MySecretKey',
 * 	'token_hmac_key' => 'MyOtherSecret',
 * 	'private_key_phrase' => 'MyCertificatePassword',
 * 	'person_service' => 'MyPeopleService',
 * 	'activity_service' => 'MyActivitiesService',
 * 	'app_data_service' => 'MyAppDataService',
 * 	'messages_service' => 'MyMessagesService',
 * 	'oauth_lookup_service' => 'MyOAuthLookupService'
 * 	'xrds_location' => 'http://www.mycontainer.com/xrds',
 * 	'check_file_exists' => false
 * );
 *
 */
$shindigConfig = array(
  // Show debug backtrace's. Disable this on a production site
  'debug' => false,
  // do real file_exist checks? Turning this off can be a big performance gain on prod servers but also risky & less verbose errors
  'check_file_exists' => true,

  // Allow plain text security tokens, this is only here to allow the sample files to work. Disable on a production site
  'allow_plaintext_token' => true,

  // Is a valid security token required to render a gadget? The token is required for doing signed preloads, but disallowing this
  // can also help prevent external parties using your rendering server (only for the paranoid :)
  'render_token_required' => false,

  // Normally we would only rewrite the gadget's html if it has the <Optional feature="content-rewrite"> set, however with this you can
  // force the content to always be rewritten
  'rewrite_by_default' => false,

  // Should we sanitize (remove scripts) from certain views? Right now this is useless, but once service sided templating and OSML is done
  // this could be useful to force (fast) html only gadgets on the profile and/or home view. Set this to false or to an array of view names like: array('profile', 'home')
  'sanitize_views' => false,

  // Compress the inlined javascript, saves upto 50% of the document size
  'compress_javascript' => true,

  // Default refresh interval for proxy/makeRequest's if none is specified in the query
  'default_refresh_interval' => 1209587,

  // The URL Prefix under which shindig lives ie if you have http://myhost.com/shindig/php set web_prefix to /shindig/php
  'web_prefix' => '',
  // If you changed the web prefix, add the prefix to these too
  'default_js_prefix' => '/gadgets/js/',
  'default_iframe_prefix' => '/gadgets/ifr?',

 'servlet_map' => array(
   '/container' => 'apache\shindig\gadgets\servlet\ContentFilesServlet',
   '/samplecontainer' => 'apache\shindig\gadgets\servlet\ContentFilesServlet',
   '/gadgets/resources' => 'apache\shindig\gadgets\servlet\ResourcesFilesServlet',
   '/gadgets/js' => 'apache\shindig\gadgets\servlet\JsServlet',
   '/gadgets/proxy' => 'apache\shindig\gadgets\servlet\ProxyServlet',
   '/gadgets/makeRequest' => 'apache\shindig\gadgets\servlet\MakeRequestServlet',
   '/gadgets/ifr' => 'apache\shindig\gadgets\servlet\GadgetRenderingServlet',
   '/gadgets/metadata' => 'apache\shindig\gadgets\servlet\MetadataServlet',
   '/gadgets/oauthcallback' => 'apache\shindig\gadgets\servlet\OAuthCallbackServlet',
   '/gadgets/api/rpc' => 'apache\shindig\social\servlet\JsonRpcServlet',
   '/gadgets/api/rest' => 'apache\shindig\social\servlet\DataServiceServlet',
   '/social/rest' => 'apache\shindig\social\servlet\DataServiceServlet',
   '/rest' => 'apache\shindig\social\servlet\DataServiceServlet',
   '/social/rpc' => 'apache\shindig\social\servlet\CompatibilityJsonRpcServlet',
   '/rpc' => 'apache\shindig\social\servlet\JsonRpcServlet',
   '/public.crt' => 'apache\shindig\gadgets\servlet\CertServlet',
   '/public.cer' => 'apache\shindig\gadgets\servlet\CertServlet',
   '/' => 'apache\shindig\gadgets\servlet\ContentFilesServlet',
 ),

  // The X-XRDS-Location value for your implementing container, see http://code.google.com/p/partuza/source/browse/trunk/Library/XRDS.php for an example
  'xrds_location' => '',

  // Allow anonymous (READ) access to the profile information? (aka REST and JSON-RPC interfaces)
  // setting this to false means you have to be authenticated through OAuth to read the data
  'allow_anonymous_token' => true,

  // The encryption keys for encrypting the security token, and the expiration of it. Make sure these match the keys used in your container/site
  'token_cipher_key' => 'INSECURE_DEFAULT_KEY',
  'token_hmac_key' => 'INSECURE_DEFAULT_KEY',
  'token_max_age' => 60 * 60,

  // Ability to customize the style thats injected into the gadget document. Don't forget to put the link/etc colors in shindig/config/container.js too!
  'gadget_css' => 'body,td,div,span,p{font-family:arial,sans-serif;} a {color:#0000cc;}a:visited {color:#551a8b;}a:active {color:#ff0000;}body{margin: 0px;padding: 0px;background-color:white;}',

  // P3P privacy policy to use for the iframe document
  'P3P' => 'CP="CAO PSA OUR"',

  // The locations of the various required components on disk. If you did a normal svn checkout there's no need to change these
  'base_path' => realpath(dirname(__FILE__) . '/..') . '/',
  'features_path' => array(
    realpath(dirname(__FILE__) . '/../features/src/main/javascript/features') . '/',
    realpath(dirname(__FILE__) . '/../extras/src/main/javascript/features-extras') . '/',
  ),
  'container_path' => realpath(dirname(__FILE__) . '/../config') . '/',
  'javascript_path' => realpath(dirname(__FILE__) . '/../content') . '/',
  'resources_path' => realpath(dirname(__FILE__) . '/../external/resources') . '/',

  // The OAuth SSL certificates to use, and the pass phrase for the private key
  'private_key_file' => realpath(dirname(__FILE__) . '/../certs') . '/private.key',
  'public_key_file' => realpath(dirname(__FILE__) . '/../certs') . '/public.crt',
  'private_key_phrase' => 'partuza',

  // the path to the json db file, used only if your using the JsonDbOpensocialService example/demo service
  'jsondb_path' => realpath(dirname(__FILE__) . '/../content/sampledata') . '/canonicaldb.json',

  // Force these libraries to be external (included through <script src="..."> tags), this way they could be cached by the browser
  // these libraries will be included regardless of the features the gadget requests
  // example: 'dynamic-height:views' includes the features dynamic-height and views
  'forcedJsLibs' => '',

  // Force these js libraries to be appended to each gadget regardless if the gadget requested them or not
  // This can be useful to overwrite existing methods of other javascript packages
  'forcedAppendedJsLibs' => array(),

  // After checking the internal __autoload function, shindig can also call the 'extension_autoloader' function to load an
  // unknown custom class, this is particuarly useful for when intergrating shindig into an existing framework that also depends on autoloading
  'extension_autoloader' => false,

  // Configurable classes. Change these to the class name to use, and make sure the auto-loader can find them
  'blacklist_class' => 'apache\shindig\gadgets\sample\BasicGadgetBlacklist',
  'remote_content' => 'apache\shindig\common\sample\BasicRemoteContent',
  'remote_content_fetcher' => 'apache\shindig\common\sample\BasicRemoteContentFetcher',
  'security_token_signer' => 'apache\shindig\common\sample\BasicSecurityTokenDecoder',
  'security_token' => 'apache\shindig\common\sample\BasicSecurityToken',
  'oauth_lookup_service' => 'apache\shindig\common\sample\BasicOAuthLookupService',
  // The OAuth Store is used to store the (gadgets/)oauth proxy credentials it obtained on behalf of the user/gadget combo
  'oauth_store' => 'apache\shindig\gadgets\oauth\BasicOAuthStore',
  'gadget_oauth_token_store' => 'apache\shindig\gadgets\oauth\BasicGadgetOAuthTokenStore',

  // handler for ApiServlet
  'service_handler' => array(
    'people' => 'apache\shindig\social\service\PersonHandler',
    'activities' => 'apache\shindig\social\service\ActivityHandler',
    'appdata' => 'apache\shindig\social\service\AppDataHandler',
    'groups' => 'apache\shindig\social\service\GroupHandler',
    'messages' => 'apache\shindig\social\service\MessagesHandler',
    'cache'  => 'apache\shindig\social\service\InvalidateHandler',
    'system' => 'apache\shindig\social\service\SystemHandler',
    'albums' => 'apache\shindig\social\service\AlbumHandler',
    'mediaitems' => 'apache\shindig\social\service\MediaItemHandler',
    'http' => 'apache\shindig\social\service\HttpHandler',
  ),

  // class is the name of the concrete input converter class
  // targetField is the name of the field where the decoded array will be inserted
  // into the params array or null if you want to overwrite params with the decoded
  // array or false if you do not want to add the decoded params
  'service_input_converter' => array(
    'people' => array('class' => 'apache\shindig\social\converters\InputPeopleConverter', 'targetField' => false),
    'activities' => array('class' => 'apache\shindig\social\converters\InputActivitiesConverter', 'targetField' => 'activity'),
    'appdata' => array('class' => 'apache\shindig\social\converters\InputAppDataConverter', 'targetField' => 'data'),
    'messages' => array('class' => 'apache\shindig\social\converters\InputMessagesConverter', 'targetField' => 'entity'),
    'cache'  => array('class' => 'apache\shindig\social\converters\InputInvalidateConverter', 'targetField' => null),
    'albums' => array('class' => 'apache\shindig\social\converters\InputAlbumsConverter', 'targetField' => 'album'),
    'mediaitems' => array('class' => 'apache\shindig\social\converters\InputMediaItemsConverter', 'targetField' => 'mediaItem'),
  ),

  // available gadget renderer with the class as key and the needed attributes in the
  // view's content block to choose this renderer. If constraint's value is a string
  // the attribute value has to match this string, if it's a boolean the attribute
  // just has to be available or not available
  'gadget_renderer' => array(
    'apache\shindig\gadgets\render\GadgetHtmlRenderer' => array('type' => 'HTML', 'href' => false),
    'apache\shindig\gadgets\render\GadgetHrefRenderer' => array('type' => 'HTML', 'href' => true),
    'apache\shindig\gadgets\render\GadgetUrlRenderer'  => array('type' => 'URL'),
  ),

  'gadget_class' => 'apache\shindig\gadgets\Gadget',
  'gadget_context_class' => 'apache\shindig\gadgets\GadgetContext',
  'gadget_factory_class' => 'apache\shindig\gadgets\GadgetFactory',
  'gadget_spec_parser' => 'apache\shindig\gadgets\GadgetSpecParser',
  'gadget_spec_class' => 'apache\shindig\gadgets\GadgetSpec',
  'substitution_class' => 'apache\shindig\gadgets\Substitutions',
  'proxy_handler' => 'apache\shindig\gadgets\ProxyHandler',
  'makerequest_handler' => 'apache\shindig\gadgets\MakeRequestHandler',
  'makerequest_class' => 'apache\shindig\gadgets\MakeRequest',
  'container_config_class' => 'apache\shindig\gadgets\ContainerConfig',

  // Caching back-end's to use. Shindig ships with CacheStorageFile, CacheStorageApc and CacheStorageMemcache support
  // The data cache is primarily used for remote content (proxied files, gadget spec, etc)
  // and the feature_cache is used to cache the parsed features xml structure and javascript
  // On a production system you probably want to use CacheStorageApc for features, and CacheStorageMemcache for the data cache
  
  //disable caching therefore the following is commented 
  'data_cache' => 'apache\shindig\common\sample\CacheStorageDummy',
  'feature_cache' => 'apache\shindig\common\sample\CacheStorageDummy',

  
  // RESTful API data service classes to use
  // See http://code.google.com/p/partuza/source/browse/#svn/trunk/Shindig for a MySql powered example
  'person_service' => 'apache\shindig\social\sample\JsonDbOpensocialService',
  'activity_service' => 'apache\shindig\social\sample\JsonDbOpensocialService',
  'app_data_service' => 'apache\shindig\social\sample\JsonDbOpensocialService',
  'group_service' => 'apache\shindig\social\sample\JsonDbOpensocialService',
  'messages_service' => 'apache\shindig\social\sample\JsonDbOpensocialService',
  'invalidate_service' => 'apache\shindig\social\sample\DefaultInvalidateService',
  'album_service' => 'apache\shindig\social\sample\JsonDbOpensocialService',
  'media_item_service' => 'apache\shindig\social\sample\JsonDbOpensocialService',

  // Also scan these directories when looking for <Class>.php files. You can include multiple paths by seperating them with a ,
  // To enable classes in the extras package you have to add this class path
  // 'extension_class_paths' => '../extras/src/main/php/extras',
  'extension_class_paths' => '',

  'userpref_param_prefix' => 'up_',
  'libs_param_name' => 'libs',

  // If you use CacheStorageMemcache as caching backend, change these to the memcache server settings
  'cache_host' => 'localhost',
  'cache_port' => 11211,
  // When using CacheStorageMemcache, should we use pconnect? There are some reports that apache/mpm + memcache_pconnect can lead to segfaults
  'cache_memcache_pconnect' => true,
  'cache_time' => 24 * 60 * 60,
  // If you use CacheStorageFile as caching backend, this is the directory where it stores the temporary files
  'cache_root' => sys_get_temp_dir() . '/shindig',

  // connection timeout setting for all curl requests, set this time something low if you want errors reported
  // quicker to the end user, and high (between 10 and 20) if your on a slow connection
  'curl_connection_timeout' => '10',
  'curl_request_timeout' => '10',

  // If your development server is behind a proxy, enter the proxy details here in 'proxy.host.com:port' format.
  'proxy' => '',

  // If your server is behind a reverse proxy, set the real hostname here so that OAuth signatures match up, for example:
  // 'http_host' => 'modules.partuza.nl'
  'http_host' => false,

  // Container id, used for security token
  'container_id' => 'default'
);
