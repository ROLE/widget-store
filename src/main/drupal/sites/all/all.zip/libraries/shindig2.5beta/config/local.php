<?php
$shindigConfig = array(
	//TODO: find a better way to define the shindig prefix
	// The URL Prefix under which shindig lives ie if you have http://myhost.com/shindig/php set web_prefix to /shindig/php
  'web_prefix' => '',
);